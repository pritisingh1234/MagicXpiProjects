package ISO8583;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.TimerTask;
import org.apache.log4j.Logger;

import com.magicsoftware.xpi.sdk.SDKException;
import com.magicsoftware.xpi.sdk.UserProperty;
import com.magicsoftware.xpi.sdk.trigger.TriggerGeneralParams;
import com.magicsoftware.xpi.sdk.trigger.external.FlowLauncher;
import com.magicsoftware.xpi.sdk.trigger.external.IExternalTrigger;
import com.magicsoftware.xpi.sdk.trigger.external.Response;
import com.sun.javafx.collections.MappingChange.Map;

import java.util.Timer;

public class Runtime implements IExternalTrigger{
	
	private final static Logger log = Logger.getLogger("MyTriggerLoggerName");
	
	/*
	In order to use the log4j infrastructure you should add your own logger and appender to the log4j.xml found under runtime/java/classes
	
	Please use the following as an example but use your own logger name, appender name and log file name.
	
	Notice that this appender defines its own log file called mytriggerlog_${pid}
	
	<appender name="magicxpi-mytrigger-appender" class="org.apache.log4j.RollingFileAppender">
		<param name="Threshold" value="&fileDefThreshold;"/>
     	<param name="File" value="${com.magicsoftware.ibolt.home}/logs/java/mytriggerlog_${pid}.log"/>
	 	<param name="MaxFileSize" value="&fileSize;"/>
	 	<param name="MaxBackupIndex" value="&fileBackups;"/>
		<layout class="org.apache.log4j.PatternLayout">
			<param name="ConversionPattern" value="&XpiPattern;"/>
		</layout>	
  	</appender>
	
	In addition you should add a logger that has the same name as the one defined in the class logger declaration. In this logger you can define the requested log level.
	The logger should reference the appender:
	
		<logger name="MyTriggerLoggerName" additivity="false">
	  	<level value="debug"/>
		<appender-ref ref="magicxpi-mytrigger-appender"/>
	</logger>
	
	Please note that in order to get debug messages in the log the entry fileDefThreshold in the log4j.xml should be set to debug: <!ENTITY fileDefThreshold "debug">
	
	*/
	
	
	private FlowLauncher launcher;
	private int counter=0;
	private Timer timer;
	SimpleDateFormat df = null;
	Map<String,String> service=null;
	String IP=null;
	String incommingRequest=null;
	int port=0;
	@Override
	public void disable() {
		// Called when the flow is disabled. 
	}

	@Override
	public void enable() {
		// Called when the flow is enabled. 
	}
	@Override
	public void load(TriggerGeneralParams generalParams, FlowLauncher fl) throws SDKException {
		HashMap<String, String> service =generalParams.getServiceObject();
		launcher=fl;
		service=new HashMap<>();
		service=generalParams.getServiceObject();
		if (service.containsKey("IP"))
			IP = service.get("IP");
		if (service.containsKey("Port"))
			port = Integer.parseInt(service.get("Port"));
		System.out.println("load()...");
		System.out.println("IP..."+IP);
		System.out.println("port.."+port);
		//getting the configuration properties from the TriggerGeneralParams object
		//UserProperty up = generalParams.getConfigurations().get("MyAlphaConfig");
		//log.debug("Trigger load. MyAlphaConfig = "+up.getValue().toString());
		
		//The external trigger should start a new thread for its listening and invocation activities!!!
		// In order to simulate this activity, the example is defining a timer.
		timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask() {
			  @Override
			  public void run() {
			    call();
			  }
			}, 1000, 1000);
		
		//In case of error in the load method, you should throw an SDKException with error code and description. The error code must match one of the errors
		//defined in the connectors errors list
		
		//throw new SDKException(101,"Some Error from the load method of the trigger");
		
	}
	
	

	@Override
	public void unload() {
		//will be called when the engine shuts down.
	}
	
	private void call(){
		//preparing the input value for the flow invocation
		HashMap<String, Object> args = new HashMap<String, Object>();
		args.put("inputvalue", "some String "+(counter++));
		df=new SimpleDateFormat("YYYY_MM_dd_HH_mm_ss");
		String timestamp = df.format(new Date());
		System.out.println("call()..."+timestamp);
		try {
			//calling the flow.
			//In case the trigger is configured as Async, the call returns once the flow request message is in the space
			//In case the trigger is configured as Sync, the invoke operation will be blocked till the flow is complete 
			try{  
				ServerSocket ss=new ServerSocket(port);  
				Socket s=ss.accept();//establishes connection   
				DataInputStream dis=new DataInputStream(s.getInputStream());  
				String  str=(String)dis.readUTF();  
				System.out.println("message= "+str); 
				String filename="D:/Incomming_Data_"+timestamp+"_.txt";
				System.out.println(filename);
				 try {
				      File myObj = new File(filename);
				      if (myObj.createNewFile()) {
				        System.out.println("File created: " + myObj.getName());
				      } 
				    	  FileWriter myWriter = new FileWriter(filename);
				          myWriter.write("Files in Java might be tricky, but it is fun enough!");
				          myWriter.close();
				      
				    } catch (Exception e) {
				      System.out.println("An error occurred.");
				      e.printStackTrace();
				    }
				ss.close();  
				}catch(Exception e){System.out.println(e);}  
			Response result = launcher.invoke(args);
			
			if(result!=null)
			{
				//In case of sync trigger, getting the flow result:
				UserProperty userP=result.getData("resultvalue");
			
				//converting the flow return value to a String. Be aware of the byte array encoding when doing the conversion
				String s=new String(((byte [] )userP.getValue()));
				
				log.debug("Flow return value = "+s);
				
			
		    
			}
			
		} catch (Exception e) {
			// You can use the log4j infrastructure already loaded by Magic xpi and write to your own log
			log.error("Invoke flow has failed",e);
		}
	}

}
