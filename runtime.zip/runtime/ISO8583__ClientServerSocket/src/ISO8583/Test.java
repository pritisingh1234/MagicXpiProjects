package ISO8583;

import java.util.HashMap;

import com.magicsoftware.xpi.sdk.SDKException;
import com.magicsoftware.xpi.sdk.trigger.TriggerGeneralParams;
import com.magicsoftware.xpi.sdk.trigger.external.FlowLauncher;

public class Test {
public static void main(String[] args) throws SDKException {
	Runtime run=new Runtime();
	TriggerGeneralParams  triggerGeneralParams=new TriggerGeneralParams(); 
	FlowLauncher fl=new FlowLauncher();
	HashMap<String,String> map=new HashMap<String,String>();
	map.put("IP","127.0.0.1");
	map.put("Port","6666");
	triggerGeneralParams.setServiceObject(map);
	run.load(triggerGeneralParams, fl);
	
}
}
